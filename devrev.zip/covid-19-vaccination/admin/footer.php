<style type="text/css">
<!--
.style1 {
	color: #000000;
	font-weight: bold;
}
-->
</style>
 <div class="footer">
          <div class="style1"> 2022 &copy; Oto-obong, Samuel Mfonobong .FPU/AS/COM/ND/19/018 .Computer Science dept. Federal Polytechnic , Ukana. All rights reserved..</div>
</div>
